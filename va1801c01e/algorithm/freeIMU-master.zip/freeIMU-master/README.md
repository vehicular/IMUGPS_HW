freeIMU
=======

The bzr export of the FreeIMU 4.0, originally designed by Fabio Varesano.

For the latest work on the FreeIMU library, see https://github.com/mjs513/FreeIMU-Updates

Please note (and especially for Mac OSX): You will need to download and place PyPy (pypy.org) version 1.9 (or possibly higher) in the correct directories, as github doesn't seem to want to import all the binaries correctly.
You will also need wxPython 2.9 (for the Mac OSX client) or higher, and python 2.7.3 or higher (again, the Mac OSX client)

